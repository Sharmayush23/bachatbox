class DigitalWallet {
    constructor() {
        this.balance = parseFloat(localStorage.getItem('walletBalance')) || 0;
        this.transactions = JSON.parse(localStorage.getItem('transactions')) || [];
        this.goals = JSON.parse(localStorage.getItem('financialGoals')) || [];
        this.initializeWallet();
    }

    initializeWallet() {
        this.updateBalanceDisplay();
        this.setupEventListeners();
        this.displayTransactions();
    }

    updateBalanceDisplay() {
        document.getElementById('walletBalance').textContent = `₹${this.balance.toFixed(2)}`;
    }

    setupEventListeners() {
        // Add Money Button
        const addMoneyBtn = document.getElementById('addMoneyBtn');
        const modal = document.getElementById('addMoneyModal');
        const closeModal = document.querySelector('.close-modal');

        addMoneyBtn.addEventListener('click', () => {
            modal.style.display = 'block';
        });

        closeModal.addEventListener('click', () => {
            modal.style.display = 'none';
        });

        // Add Money Form
        const addMoneyForm = document.getElementById('addMoneyForm');
        addMoneyForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const amount = parseFloat(document.getElementById('addAmount').value);
            this.addMoney(amount);
            modal.style.display = 'none';
            addMoneyForm.reset();
        });

        // Payment Form
        const paymentForm = document.getElementById('paymentForm');
        paymentForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const upiId = document.getElementById('receiverUPI').value;
            const amount = parseFloat(document.getElementById('paymentAmount').value);
            const category = document.getElementById('paymentCategory').value;
            this.makePayment(upiId, amount, category);
            paymentForm.reset();
        });

        // Add Goal Form
        const addGoalForm = document.getElementById('addGoalForm');
        if (addGoalForm) {
            addGoalForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const goalName = document.getElementById('goalName').value;
                const targetAmount = parseFloat(document.getElementById('targetAmount').value);
                const deadline = document.getElementById('goalDeadline').value;
                this.addFinancialGoal(goalName, targetAmount, deadline);
                addGoalForm.reset();
            });
        }
    }

    addMoney(amount) {
        if (amount <= 0) {
            alert('Please enter a valid amount');
            return;
        }

        this.balance += amount;
        this.addTransaction('credit', amount, 'Added money to wallet');
        this.updateBalanceDisplay();
        this.saveToLocalStorage();
    }

    makePayment(upiId, amount, category) {
        if (amount <= 0) {
            alert('Please enter a valid amount');
            return;
        }

        if (amount > this.balance) {
            alert('Insufficient balance');
            return;
        }

        this.balance -= amount;
        this.addTransaction('debit', amount, `Paid to ${upiId} (${category})`);
        this.updateBalanceDisplay();
        this.saveToLocalStorage();
    }

    addTransaction(type, amount, description) {
        const transaction = {
            id: Date.now(),
            type,
            amount,
            description,
            timestamp: new Date().toISOString(),
            category: description.includes('(') ? description.split('(')[1].replace(')', '') : 'General'
        };

        this.transactions.unshift(transaction);
        this.displayTransactions();
        this.updateTransactionAnalysis();
    }

    updateTransactionAnalysis() {
        const analysisContainer = document.getElementById('transactionAnalysis');
        if (!analysisContainer) return;

        // Calculate totals and categories
        const analysis = this.transactions.reduce((acc, trans) => {
            if (trans.type === 'credit') {
                acc.totalIncome += trans.amount;
            } else {
                acc.totalExpenses += trans.amount;
                acc.categories[trans.category] = (acc.categories[trans.category] || 0) + trans.amount;
            }
            return acc;
        }, { totalIncome: 0, totalExpenses: 0, categories: {} });

        // Create category breakdown HTML
        const categoryBreakdown = Object.entries(analysis.categories)
            .map(([category, amount]) => ({
                category,
                amount,
                percentage: (amount / analysis.totalExpenses * 100).toFixed(1)
            }))
            .sort((a, b) => b.amount - a.amount);

        analysisContainer.innerHTML = `
            <div class="financial-metrics">
                <div class="metric-card">
                    <div class="metric-label">Total Income</div>
                    <div class="metric-value">₹${analysis.totalIncome.toFixed(2)}</div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">Total Expenses</div>
                    <div class="metric-value">₹${analysis.totalExpenses.toFixed(2)}</div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">Balance</div>
                    <div class="metric-value">₹${(analysis.totalIncome - analysis.totalExpenses).toFixed(2)}</div>
                </div>
            </div>
            <div class="category-analysis">
                <h3>Expense Breakdown</h3>
                ${categoryBreakdown.map(cat => `
                    <div class="category-item">
                        <div class="category-info">
                            <span>${cat.category}</span>
                            <span>₹${cat.amount.toFixed(2)} (${cat.percentage}%)</span>
                        </div>
                        <div class="category-bar">
                            <div class="progress-bar" style="width: ${cat.percentage}%"></div>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    displayTransactions() {
        const transactionsList = document.getElementById('transactionsList');
        transactionsList.innerHTML = this.transactions
            .map(transaction => `
                <div class="transaction-item">
                    <div>
                        <strong>${transaction.description}</strong>
                        <br>
                        <small>${new Date(transaction.timestamp).toLocaleString()}</small>
                    </div>
                    <div style="color: ${transaction.type === 'credit' ? 'green' : 'red'}">
                        ${transaction.type === 'credit' ? '+' : '-'}₹${transaction.amount.toFixed(2)}
                    </div>
                </div>
            `)
            .join('');
    }

    saveToLocalStorage() {
        localStorage.setItem('walletBalance', this.balance.toString());
        localStorage.setItem('transactions', JSON.stringify(this.transactions));
    }

    addFinancialGoal(name, targetAmount, deadline) {
        const goal = {
            id: Date.now(),
            name,
            targetAmount,
            deadline,
            currentAmount: 0,
            completed: false
        };

        this.goals.push(goal);
        this.saveGoals();
        this.displayGoals();
    }

    displayGoals() {
        const goalsContainer = document.getElementById('goalCards');
        if (!goalsContainer) return;

        goalsContainer.innerHTML = this.goals.map(goal => {
            const progress = Math.min((goal.currentAmount / goal.targetAmount) * 100, 100);
            const remainingAmount = Math.max(goal.targetAmount - goal.currentAmount, 0);
            const deadlineDate = new Date(goal.deadline);
            const daysLeft = Math.ceil((deadlineDate - new Date()) / (1000 * 60 * 60 * 24));

            return `
                <div class="goal-card ${goal.completed ? 'completed' : ''}">
                    <h3>${goal.name}</h3>
                    <div class="goal-progress">
                        <div class="progress-bar" style="width: ${progress}%"></div>
                    </div>
                    <div class="goal-details">
                        <div class="goal-amount">Target: ₹${goal.targetAmount.toFixed(2)}</div>
                        <div class="goal-status">
                            <p>Saved: ₹${goal.currentAmount.toFixed(2)}</p>
                            <p>Remaining: ₹${remainingAmount.toFixed(2)}</p>
                            <p>Progress: ${Math.round(progress)}%</p>
                            <p>${daysLeft > 0 ? `${daysLeft} days left` : 'Deadline reached'}</p>
                        </div>
                    </div>
                    ${!goal.completed ? `
                        <button onclick="wallet.contributeToGoal(${goal.id})" class="primary-btn">
                            Add to Goal
                        </button>
                    ` : '<div class="completed-badge">Goal Achieved! 🎉</div>'}
                </div>
            `;
        }).join('');
    }

    contributeToGoal(goalId) {
        const goal = this.goals.find(g => g.id === goalId);
        if (!goal) return;

        const amount = parseFloat(prompt(`Enter amount to add to "${goal.name}"`));
        if (isNaN(amount) || amount <= 0) {
            alert('Please enter a valid amount');
            return;
        }

        if (amount > this.balance) {
            alert('Insufficient wallet balance');
            return;
        }

        this.balance -= amount;
        this.updateGoalProgress(goalId, amount);
        this.addTransaction('debit', amount, `Contribution to ${goal.name}`);
        this.updateBalanceDisplay();
        this.saveToLocalStorage();
    }

    updateGoalProgress(goalId, amount) {
        const goal = this.goals.find(g => g.id === goalId);
        if (goal) {
            goal.currentAmount = parseFloat((goal.currentAmount + amount).toFixed(2));
            if (goal.currentAmount >= goal.targetAmount) {
                goal.completed = true;
                alert(`Congratulations! You've achieved your goal: ${goal.name}`);
            }
            this.saveGoals();
            this.displayGoals();
        }
    }

    saveGoals() {
        localStorage.setItem('financialGoals', JSON.stringify(this.goals));
    }
}

// Initialize the wallet when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.wallet = new DigitalWallet();
});


function displayPieChart(data) {
    const ctx = document.getElementById('expensePieChart').getContext('2d');
    
    // Destroy existing chart if it exists
    if (window.expenseChart instanceof Chart) {
        window.expenseChart.destroy();
    }

    window.expenseChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: Object.keys(data),
            datasets: [{
                data: Object.values(data),
                backgroundColor: [
                    '#3498db',
                    '#2ecc71',
                    '#e74c3c',
                    '#f1c40f',
                    '#9b59b6',
                    '#1abc9c',
                    '#e67e22',
                    '#34495e'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        font: {
                            size: 14
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: ₹${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}